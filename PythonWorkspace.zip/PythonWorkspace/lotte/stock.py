def stock():
    num = 74000
    