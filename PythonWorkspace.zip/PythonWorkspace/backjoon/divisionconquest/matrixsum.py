N, M = map(int, input().split())

for i in range(N):
    j
