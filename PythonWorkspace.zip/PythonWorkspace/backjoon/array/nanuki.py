import sys

number = []
for i in range(10):
    a = sys.stdin.readline()
    number.append(a)
