def r2():
    r1,S = map(int,input().split(" "))


    S = S * 2
    r2 = S - r1

    print(r2)

r2()