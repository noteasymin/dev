print(52)
print('ljm3749')