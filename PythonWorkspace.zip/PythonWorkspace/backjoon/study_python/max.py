import sys

def max():
    A, B = map(int,sys.stdin.readline().split(" "))
    print(A + B)

max()