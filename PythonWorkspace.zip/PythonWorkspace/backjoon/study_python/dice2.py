def dice():

    num = list(map(int,input().split()))
    num = sorted(num)
    
    if num[0] == num[1] and num[1] == num[2]:
        return 10000 + num[0] * 1000
    elif num[0] == num[1] or num[0] == num[2]:
        return 1000 + num[0] * 100
    elif num[1] == num[2]:
        return 1000 + num[1] * 100
    else:
        return max(num)*100

    

rich = []
cnt = int(input())
for i in range(cnt):
    rich.append(dice())

print(max(rich))