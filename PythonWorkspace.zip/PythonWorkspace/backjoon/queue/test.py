
queue = []
for i in range(10):
    queue.append(i+1)

print(queue.index(7))