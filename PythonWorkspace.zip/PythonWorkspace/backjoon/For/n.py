import sys
n = int(sys.stdin.readline())

for i in range(1,n+1):
    print(n+1-i)