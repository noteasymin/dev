a = int(input())

for i in range(1,a+1):
    num1, num2 = map(int,input().split())
    print(num1 + num2)