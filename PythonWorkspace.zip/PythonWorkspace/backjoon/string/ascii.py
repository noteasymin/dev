import sys

code = sys.stdin.readline().rstrip()
print(ord(code))