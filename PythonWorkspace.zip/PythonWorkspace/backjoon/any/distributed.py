import sys

def dis():
    a,b = map(int,sys.stdin.readline().split())
    
    a = a % 10

    if a == 0:
        print(10)
    elif a == 1:
        
    
;
cnt = int(sys.stdin.readline())

for i in range(cnt):
    dis()
