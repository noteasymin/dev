import sys

def world():
    in_words = list(sys.stdin.read())
    print(in_words)


world()