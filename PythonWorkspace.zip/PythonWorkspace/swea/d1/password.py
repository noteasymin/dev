A, B = map(int, input().split())

print(A-B+1)