N = int(input())
total = 0
for i in range(N):
    total += N-i

print(total)