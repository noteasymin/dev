T = int(input())
cnt = 0
for i in range(T):
    print(T+cnt,end=" ")
    cnt -= 1