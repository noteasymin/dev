N = int(input())

for _ in range(N):
    print('#',end="")