sentence = list(input())

for i in sentence:
    print(ord(i)-64,end=" ")