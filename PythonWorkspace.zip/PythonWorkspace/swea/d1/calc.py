A, B = map(int,input().split())

print(A+B)
print(A-B)
print(A*B)
print(A//B)