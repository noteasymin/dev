sentence = input()
print(sentence.upper())